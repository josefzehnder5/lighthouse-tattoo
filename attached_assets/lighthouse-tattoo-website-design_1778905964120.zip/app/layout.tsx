import type { Metadata, Viewport } from 'next'
import { Bebas_Neue, Inter } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const bebasNeue = Bebas_Neue({ 
  weight: '400',
  subsets: ['latin'],
  variable: '--font-bebas-neue',
  display: 'swap',
})

const inter = Inter({ 
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'LIGHTHOUSE TATTOO · MEDELLÍN',
  description: 'Premium underground tattoo collective in Medellín, Colombia. Black & Grey, Realismo, Blackwork. Custom designs. Book via WhatsApp.',
  keywords: ['tattoo', 'Medellín', 'Colombia', 'black and grey', 'realismo', 'blackwork', 'custom tattoo', 'underground', 'premium'],
  authors: [{ name: 'Lighthouse Tattoo' }],
  openGraph: {
    title: 'LIGHTHOUSE TATTOO · MEDELLÍN',
    description: 'Premium underground tattoo collective in Medellín, Colombia. Black & Grey, Realismo, Blackwork.',
    type: 'website',
    locale: 'de_DE',
  },
}

export const viewport: Viewport = {
  themeColor: '#0a0a0a',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="de" className={`${bebasNeue.variable} ${inter.variable} bg-black-deep`}>
      <body className="font-sans antialiased text-white bg-black-deep">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
